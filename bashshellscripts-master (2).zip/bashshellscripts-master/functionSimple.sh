#!/bin/bash
# this is a simple function example
echo "Starting the function definition..."

funcExample () {
echo "We are now INSIDE the function..."
}

funcExample